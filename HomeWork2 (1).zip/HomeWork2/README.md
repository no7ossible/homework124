# SecondLessonSchrodingersCat
<p align="left">
<img src="https://user-images.githubusercontent.com/108148690/218139960-38f08dab-4f35-4001-bf88-8d8276b6800d.jpeg"/>
</p>
